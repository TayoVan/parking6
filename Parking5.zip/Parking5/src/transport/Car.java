package transport;

public class Car extends Transport {
    public Car(String registrationNumber, String model) {
        super(registrationNumber, model, "Car");
    }
}
